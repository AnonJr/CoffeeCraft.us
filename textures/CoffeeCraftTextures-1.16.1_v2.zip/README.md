# CoffeeCraft-Texture-Pack
The textures used by the CoffeeCraft members

This is mostly a collection of textures from Vanilla Tweaks, and this shortcut will get you the bulk of them: <https://vanillatweaks.net/share#BpsjBs>

I've also added the textures for the rotation wrenches, and a couple other small changes like:

* Tame Wolf -> Black Lab from <https://www.planetminecraft.com/mob-skin/black-lab-4559911/>
* Custom Villager Voices from <https://github.com/AnonJr/Minecraft-Villager-Voices/releases>
* Shield Corrections from <https://www.planetminecraft.com/texture-pack/shield-corrections/>
* Restock Clock from <https://www.planetminecraft.com/texture-pack/restock-clock/>